
document.getElementsByClassName('form--btn-close')[0].addEventListener('click', function () {
    var formClose = document.getElementsByClassName('form')[0];
    formClose.classList.add('close-form');
})

